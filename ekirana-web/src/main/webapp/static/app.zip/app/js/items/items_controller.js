'use strict';

/**
 * Controller for Items
 **/
itemsModule.controller('ItemsCtrl', ['Items',  'Brand', 'Image', 'ItemCategory', '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(Items, Brand, Image, ItemCategory, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	 'Brand',  'Image',  'ItemCategory',     // edition mode
    $scope.mode = null;
    
	// list of itemss
    $scope.itemss = [];
	// items to edit
    $scope.items = null;

	// referencies entities
	$scope.items = {};
    // brands
	$scope.items.brands = [];
    // images
	$scope.items.images = [];
    // itemCategorys
	$scope.items.itemCategorys = [];

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
		Brand.getAllAsListItems().then(
				function(success) {
        	        $scope.items.brands = success.data;
            	}, 
	            MessageHandler.manageError);
		Image.getAllAsListItems().then(
				function(success) {
        	        $scope.items.images = success.data;
            	}, 
	            MessageHandler.manageError);
		ItemCategory.getAllAsListItems().then(
				function(success) {
        	        $scope.items.itemCategorys = success.data;
            	}, 
	            MessageHandler.manageError);
    };
    
    /**
     * Refresh itemss list
     */
    $scope.refreshItemsList = function() {
    	try {
			$scope.itemss = [];
        	Items.getAll().then(
				function(success) {
        	        $scope.itemss = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh items
     */
    $scope.refreshItems = function(itemid) {
    	try {
        	$scope.items = null;
	        Items.get(itemid).then(
				function(success) {
        	        $scope.items = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the itemss list page
     */
    $scope.goToItemsList = function() {
        $scope.refreshItemsList();
        $location.path('/items');
    }
    /**
     * Go to the items edit page
     */
    $scope.goToItems = function(itemid) {
        $scope.refreshItems(itemid);
        $location.path('/items/'+itemid);
    }

    // Actions

    /**
     * Save items
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = Items.create;
			} else {
				save = Items.update;
			}
			save($scope.items).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.items = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete items
     */
    $scope.delete = function(itemid) {
	    try {
			MessageHandler.cleanMessage();
    	    Items.delete(itemid).then(
				function(success) {
                	$scope.goToItemsList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.items = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.itemid != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshItems($routeParams.itemid);
    } else {
        // List page
        $scope.refreshItemsList();
    }
    
    
}]);
