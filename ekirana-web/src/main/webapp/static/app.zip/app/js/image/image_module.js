'use strict';

/* Module for Image */

var imageModule = angular.module('image.module', ['myApp']);

/**
 * Module for image
 */
imageModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/image',    {templateUrl: 'partials/image/image_list.html', controller: 'ImageCtrl'});
    $routeProvider.when('/image/new', {templateUrl: 'partials/image/image_form.html', controller: 'ImageCtrl'});
    $routeProvider.when('/image/:id', {templateUrl: 'partials/image/image_form.html', controller: 'ImageCtrl'});
}]);
