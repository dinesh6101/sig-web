'use strict';

/**
 * Controller for Image
 **/
imageModule.controller('ImageCtrl', ['Image',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(Image, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of images
    $scope.images = [];
	// image to edit
    $scope.image = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh images list
     */
    $scope.refreshImageList = function() {
    	try {
			$scope.images = [];
        	Image.getAll().then(
				function(success) {
        	        $scope.images = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh image
     */
    $scope.refreshImage = function(id) {
    	try {
        	$scope.image = null;
	        Image.get(id).then(
				function(success) {
        	        $scope.image = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the images list page
     */
    $scope.goToImageList = function() {
        $scope.refreshImageList();
        $location.path('/image');
    }
    /**
     * Go to the image edit page
     */
    $scope.goToImage = function(id) {
        $scope.refreshImage(id);
        $location.path('/image/'+id);
    }

    // Actions

    /**
     * Save image
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = Image.create;
			} else {
				save = Image.update;
			}
			save($scope.image).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.image = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete image
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    Image.delete(id).then(
				function(success) {
                	$scope.goToImageList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.image = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshImage($routeParams.id);
    } else {
        // List page
        $scope.refreshImageList();
    }
    
    
}]);
