'use strict';

/* Module for OrderNotifications */

var orderNotificationsModule = angular.module('orderNotifications.module', ['myApp']);

/**
 * Module for orderNotifications
 */
orderNotificationsModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/orderNotifications',    {templateUrl: 'partials/ordernotifications/ordernotifications_list.html', controller: 'OrderNotificationsCtrl'});
    $routeProvider.when('/orderNotifications/new', {templateUrl: 'partials/ordernotifications/ordernotifications_form.html', controller: 'OrderNotificationsCtrl'});
    $routeProvider.when('/orderNotifications/:id', {templateUrl: 'partials/ordernotifications/ordernotifications_form.html', controller: 'OrderNotificationsCtrl'});
}]);
