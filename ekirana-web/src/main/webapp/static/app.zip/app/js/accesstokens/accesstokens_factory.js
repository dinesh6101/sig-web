'use strict';

/**
 * Factory for AccessTokens
 */
accessTokensModule.factory('AccessTokens', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage accessTokens
    var entityURL = restURL + '/accessTokens';
	
	/**
     * Validate accessTokens
     * @param accessTokens accessTokens
     * @throws validation exception
     */
	var validate = function (accessTokens) {
		var errors = [];
        if( accessTokens.tokenid == null || accessTokens.tokenid == '' ) {
			errors.push('accessTokens.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all accessTokenss as list items
         * @return all accessTokenss as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/accessTokens');
    	},

        /**
         * Get all accessTokenss
         * @return all accessTokenss
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get accessTokens
         * @param tokenid tokenid
         * @return accessTokens
         */
    	get: function(tokenid) {
    	    var url = entityURL + '/' + tokenid;
        	return $http.get(url);
    	},

        /**
         * Create a new accessTokens
         * @param accessTokens accessTokens
         * @return accessTokens saved
         */
		create: function(accessTokens) {
			validate(accessTokens)
			var url = entityURL;
			return $http.post(url, accessTokens);
    	},

        /**
         * Update accessTokens
         * @param accessTokens accessTokens
         * @return accessTokens saved
         */
    	update: function(accessTokens) {
			validate(accessTokens)
			var url = entityURL + '/' + accessTokens.tokenid;
			return $http.put(url, accessTokens);
    	},

		/**
         * Delete accessTokens
         * @param tokenid tokenid
         */
    	delete: function(tokenid) {
        	var url = entityURL + '/' + tokenid;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

