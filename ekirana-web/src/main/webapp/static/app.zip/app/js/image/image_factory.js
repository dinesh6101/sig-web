'use strict';

/**
 * Factory for Image
 */
imageModule.factory('Image', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage image
    var entityURL = restURL + '/image';
	
	/**
     * Validate image
     * @param image image
     * @throws validation exception
     */
	var validate = function (image) {
		var errors = [];
        if( image.id == null || image.id == '' ) {
			errors.push('image.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all images as list items
         * @return all images as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/image');
    	},

        /**
         * Get all images
         * @return all images
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get image
         * @param id id
         * @return image
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new image
         * @param image image
         * @return image saved
         */
		create: function(image) {
			validate(image)
			var url = entityURL;
			return $http.post(url, image);
    	},

        /**
         * Update image
         * @param image image
         * @return image saved
         */
    	update: function(image) {
			validate(image)
			var url = entityURL + '/' + image.id;
			return $http.put(url, image);
    	},

		/**
         * Delete image
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

