'use strict';

/* Module for ItemOffers */

var itemOffersModule = angular.module('itemOffers.module', ['myApp']);

/**
 * Module for itemOffers
 */
itemOffersModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/itemOffers',    {templateUrl: 'partials/itemoffers/itemoffers_list.html', controller: 'ItemOffersCtrl'});
    $routeProvider.when('/itemOffers/new', {templateUrl: 'partials/itemoffers/itemoffers_form.html', controller: 'ItemOffersCtrl'});
    $routeProvider.when('/itemOffers/:id', {templateUrl: 'partials/itemoffers/itemoffers_form.html', controller: 'ItemOffersCtrl'});
}]);
