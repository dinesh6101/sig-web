'use strict';

/**
 * Controller for AccessUser
 **/
accessUserModule.controller('AccessUserCtrl', ['AccessUser',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(AccessUser, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of accessUsers
    $scope.accessUsers = [];
	// accessUser to edit
    $scope.accessUser = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh accessUsers list
     */
    $scope.refreshAccessUserList = function() {
    	try {
			$scope.accessUsers = [];
        	AccessUser.getAll().then(
				function(success) {
        	        $scope.accessUsers = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh accessUser
     */
    $scope.refreshAccessUser = function(userid) {
    	try {
        	$scope.accessUser = null;
	        AccessUser.get(userid).then(
				function(success) {
        	        $scope.accessUser = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the accessUsers list page
     */
    $scope.goToAccessUserList = function() {
        $scope.refreshAccessUserList();
        $location.path('/accessUser');
    }
    /**
     * Go to the accessUser edit page
     */
    $scope.goToAccessUser = function(userid) {
        $scope.refreshAccessUser(userid);
        $location.path('/accessUser/'+userid);
    }

    // Actions

    /**
     * Save accessUser
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = AccessUser.create;
			} else {
				save = AccessUser.update;
			}
			save($scope.accessUser).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.accessUser = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete accessUser
     */
    $scope.delete = function(userid) {
	    try {
			MessageHandler.cleanMessage();
    	    AccessUser.delete(userid).then(
				function(success) {
                	$scope.goToAccessUserList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.accessUser = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.userid != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshAccessUser($routeParams.userid);
    } else {
        // List page
        $scope.refreshAccessUserList();
    }
    
    
}]);
