'use strict';

/**
 * Factory for OrderNotifications
 */
orderNotificationsModule.factory('OrderNotifications', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage orderNotifications
    var entityURL = restURL + '/orderNotifications';
	
	/**
     * Validate orderNotifications
     * @param orderNotifications orderNotifications
     * @throws validation exception
     */
	var validate = function (orderNotifications) {
		var errors = [];
        if( orderNotifications.id == null || orderNotifications.id == '' ) {
			errors.push('orderNotifications.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all orderNotificationss as list items
         * @return all orderNotificationss as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/orderNotifications');
    	},

        /**
         * Get all orderNotificationss
         * @return all orderNotificationss
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get orderNotifications
         * @param id id
         * @return orderNotifications
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new orderNotifications
         * @param orderNotifications orderNotifications
         * @return orderNotifications saved
         */
		create: function(orderNotifications) {
			validate(orderNotifications)
			var url = entityURL;
			return $http.post(url, orderNotifications);
    	},

        /**
         * Update orderNotifications
         * @param orderNotifications orderNotifications
         * @return orderNotifications saved
         */
    	update: function(orderNotifications) {
			validate(orderNotifications)
			var url = entityURL + '/' + orderNotifications.id;
			return $http.put(url, orderNotifications);
    	},

		/**
         * Delete orderNotifications
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

