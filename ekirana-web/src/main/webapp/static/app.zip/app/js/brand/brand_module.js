'use strict';

/* Module for Brand */

var brandModule = angular.module('brand.module', ['myApp']);

/**
 * Module for brand
 */
brandModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/brand',    {templateUrl: 'partials/brand/brand_list.html', controller: 'BrandCtrl'});
    $routeProvider.when('/brand/new', {templateUrl: 'partials/brand/brand_form.html', controller: 'BrandCtrl'});
    $routeProvider.when('/brand/:brandid', {templateUrl: 'partials/brand/brand_form.html', controller: 'BrandCtrl'});
}]);
