'use strict';

/**
 * Controller for OrderNotifications
 **/
orderNotificationsModule.controller('OrderNotificationsCtrl', ['OrderNotifications',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(OrderNotifications, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of orderNotificationss
    $scope.orderNotificationss = [];
	// orderNotifications to edit
    $scope.orderNotifications = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh orderNotificationss list
     */
    $scope.refreshOrderNotificationsList = function() {
    	try {
			$scope.orderNotificationss = [];
        	OrderNotifications.getAll().then(
				function(success) {
        	        $scope.orderNotificationss = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh orderNotifications
     */
    $scope.refreshOrderNotifications = function(id) {
    	try {
        	$scope.orderNotifications = null;
	        OrderNotifications.get(id).then(
				function(success) {
        	        $scope.orderNotifications = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the orderNotificationss list page
     */
    $scope.goToOrderNotificationsList = function() {
        $scope.refreshOrderNotificationsList();
        $location.path('/orderNotifications');
    }
    /**
     * Go to the orderNotifications edit page
     */
    $scope.goToOrderNotifications = function(id) {
        $scope.refreshOrderNotifications(id);
        $location.path('/orderNotifications/'+id);
    }

    // Actions

    /**
     * Save orderNotifications
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = OrderNotifications.create;
			} else {
				save = OrderNotifications.update;
			}
			save($scope.orderNotifications).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.orderNotifications = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete orderNotifications
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    OrderNotifications.delete(id).then(
				function(success) {
                	$scope.goToOrderNotificationsList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.orderNotifications = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshOrderNotifications($routeParams.id);
    } else {
        // List page
        $scope.refreshOrderNotificationsList();
    }
    
    
}]);
