'use strict';

/* Module for AccessRoleTokens */

var signUpModule = angular.module('signUp.module', ['myApp']);

/**
 * Module for signUp
 */
signUpModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/signUp',{templateUrl: 'partials/signup/signup_list.html', controller: 'SignUpCtrl'});
    $routeProvider.when('/signUp/new',{templateUrl: 'partials/signup/signup_form.html', controller: 'SignUpCtrl'});
    $routeProvider.when('/signUp/:firstName',{templateUrl: 'partials/signup/signup_form.html', controller: 'SignUpCtrl'});
}]);
