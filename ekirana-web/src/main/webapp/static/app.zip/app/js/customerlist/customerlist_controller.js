'use strict';

/**
 * Controller for CustomerList
 **/
customerListModule.controller('CustomerListCtrl', ['CustomerList',  'Customer', '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(CustomerList, Customer, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	 'Customer',     // edition mode
    $scope.mode = null;
    
	// list of customerLists
    $scope.customerLists = [];
	// customerList to edit
    $scope.customerList = null;

	// referencies entities
	$scope.items = {};
    // customers
	$scope.items.customers = [];

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
		Customer.getAllAsListItems().then(
				function(success) {
        	        $scope.items.customers = success.data;
            	}, 
	            MessageHandler.manageError);
    };
    
    /**
     * Refresh customerLists list
     */
    $scope.refreshCustomerListList = function() {
    	try {
			$scope.customerLists = [];
        	CustomerList.getAll().then(
				function(success) {
        	        $scope.customerLists = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh customerList
     */
    $scope.refreshCustomerList = function(id) {
    	try {
        	$scope.customerList = null;
	        CustomerList.get(id).then(
				function(success) {
        	        $scope.customerList = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the customerLists list page
     */
    $scope.goToCustomerListList = function() {
        $scope.refreshCustomerListList();
        $location.path('/customerList');
    }
    /**
     * Go to the customerList edit page
     */
    $scope.goToCustomerList = function(id) {
        $scope.refreshCustomerList(id);
        $location.path('/customerList/'+id);
    }

    // Actions

    /**
     * Save customerList
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = CustomerList.create;
			} else {
				save = CustomerList.update;
			}
			save($scope.customerList).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.customerList = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete customerList
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    CustomerList.delete(id).then(
				function(success) {
                	$scope.goToCustomerListList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.customerList = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshCustomerList($routeParams.id);
    } else {
        // List page
        $scope.refreshCustomerListList();
    }
    
    
}]);
