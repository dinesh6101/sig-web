'use strict';

/**
 * Factory for List
 */
listModule.factory('List', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage list
    var entityURL = restURL + '/list';
	
	/**
     * Validate list
     * @param list list
     * @throws validation exception
     */
	var validate = function (list) {
		var errors = [];
        if( list.id == null || list.id == '' ) {
			errors.push('list.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all lists as list items
         * @return all lists as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/list');
    	},

        /**
         * Get all lists
         * @return all lists
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get list
         * @param id id
         * @return list
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new list
         * @param list list
         * @return list saved
         */
		create: function(list) {
			validate(list)
			var url = entityURL;
			return $http.post(url, list);
    	},

        /**
         * Update list
         * @param list list
         * @return list saved
         */
    	update: function(list) {
			validate(list)
			var url = entityURL + '/' + list.id;
			return $http.put(url, list);
    	},

		/**
         * Delete list
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

