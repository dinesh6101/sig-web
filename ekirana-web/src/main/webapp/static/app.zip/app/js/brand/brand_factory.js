'use strict';

/**
 * Factory for Brand
 */
brandModule.factory('Brand', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage brand
    var entityURL = restURL + '/brand';
	
	/**
     * Validate brand
     * @param brand brand
     * @throws validation exception
     */
	var validate = function (brand) {
		var errors = [];
        if( brand.brandid == null || brand.brandid == '' ) {
			errors.push('brand.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all brands as list items
         * @return all brands as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/brand');
    	},

        /**
         * Get all brands
         * @return all brands
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get brand
         * @param brandid brandid
         * @return brand
         */
    	get: function(brandid) {
    	    var url = entityURL + '/' + brandid;
        	return $http.get(url);
    	},

        /**
         * Create a new brand
         * @param brand brand
         * @return brand saved
         */
		create: function(brand) {
			validate(brand)
			var url = entityURL;
			return $http.post(url, brand);
    	},

        /**
         * Update brand
         * @param brand brand
         * @return brand saved
         */
    	update: function(brand) {
			validate(brand)
			var url = entityURL + '/' + brand.brandid;
			return $http.put(url, brand);
    	},

		/**
         * Delete brand
         * @param brandid brandid
         */
    	delete: function(brandid) {
        	var url = entityURL + '/' + brandid;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

