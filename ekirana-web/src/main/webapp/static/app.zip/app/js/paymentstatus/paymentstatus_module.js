'use strict';

/* Module for PaymentStatus */

var paymentStatusModule = angular.module('paymentStatus.module', ['myApp']);

/**
 * Module for paymentStatus
 */
paymentStatusModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/paymentStatus',    {templateUrl: 'partials/paymentstatus/paymentstatus_list.html', controller: 'PaymentStatusCtrl'});
    $routeProvider.when('/paymentStatus/new', {templateUrl: 'partials/paymentstatus/paymentstatus_form.html', controller: 'PaymentStatusCtrl'});
    $routeProvider.when('/paymentStatus/:id', {templateUrl: 'partials/paymentstatus/paymentstatus_form.html', controller: 'PaymentStatusCtrl'});
}]);
