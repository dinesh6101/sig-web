'use strict';

/**
 * Factory for AccessUser
 */
accessUserModule.factory('AccessUser', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage accessUser
    var entityURL = restURL + '/accessUser';
	
	/**
     * Validate accessUser
     * @param accessUser accessUser
     * @throws validation exception
     */
	var validate = function (accessUser) {
		var errors = [];
        if( accessUser.userid == null || accessUser.userid == '' ) {
			errors.push('accessUser.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all accessUsers as list items
         * @return all accessUsers as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/accessUser');
    	},

        /**
         * Get all accessUsers
         * @return all accessUsers
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get accessUser
         * @param userid userid
         * @return accessUser
         */
    	get: function(userid) {
    	    var url = entityURL + '/' + userid;
        	return $http.get(url);
    	},

        /**
         * Create a new accessUser
         * @param accessUser accessUser
         * @return accessUser saved
         */
		create: function(accessUser) {
			validate(accessUser)
			var url = entityURL;
			return $http.post(url, accessUser);
    	},

        /**
         * Update accessUser
         * @param accessUser accessUser
         * @return accessUser saved
         */
    	update: function(accessUser) {
			validate(accessUser)
			var url = entityURL + '/' + accessUser.userid;
			return $http.put(url, accessUser);
    	},

		/**
         * Delete accessUser
         * @param userid userid
         */
    	delete: function(userid) {
        	var url = entityURL + '/' + userid;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

