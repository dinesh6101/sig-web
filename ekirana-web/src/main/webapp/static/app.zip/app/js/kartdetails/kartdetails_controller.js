'use strict';

/**
 * Controller for KartDetails
 **/
kartDetailsModule.controller('KartDetailsCtrl', ['KartDetails',  'Customer', 'Items', '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(KartDetails, Customer, Items, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	 'Customer',  'Items',     // edition mode
    $scope.mode = null;
    
	// list of kartDetailss
    $scope.kartDetailss = [];
	// kartDetails to edit
    $scope.kartDetails = null;

	// referencies entities
	$scope.items = {};
    // customers
	$scope.items.customers = [];
    // itemss
	$scope.items.itemss = [];

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
		Customer.getAllAsListItems().then(
				function(success) {
        	        $scope.items.customers = success.data;
            	}, 
	            MessageHandler.manageError);
		Items.getAllAsListItems().then(
				function(success) {
        	        $scope.items.itemss = success.data;
            	}, 
	            MessageHandler.manageError);
    };
    
    /**
     * Refresh kartDetailss list
     */
    $scope.refreshKartDetailsList = function() {
    	try {
			$scope.kartDetailss = [];
        	KartDetails.getAll().then(
				function(success) {
        	        $scope.kartDetailss = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh kartDetails
     */
    $scope.refreshKartDetails = function(id) {
    	try {
        	$scope.kartDetails = null;
	        KartDetails.get(id).then(
				function(success) {
        	        $scope.kartDetails = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the kartDetailss list page
     */
    $scope.goToKartDetailsList = function() {
        $scope.refreshKartDetailsList();
        $location.path('/kartDetails');
    }
    /**
     * Go to the kartDetails edit page
     */
    $scope.goToKartDetails = function(id) {
        $scope.refreshKartDetails(id);
        $location.path('/kartDetails/'+id);
    }

    // Actions

    /**
     * Save kartDetails
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = KartDetails.create;
			} else {
				save = KartDetails.update;
			}
			save($scope.kartDetails).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.kartDetails = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete kartDetails
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    KartDetails.delete(id).then(
				function(success) {
                	$scope.goToKartDetailsList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.kartDetails = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshKartDetails($routeParams.id);
    } else {
        // List page
        $scope.refreshKartDetailsList();
    }
    
    
}]);
