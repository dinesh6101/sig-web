'use strict';

/* Module for PaymentMode */

var paymentModeModule = angular.module('paymentMode.module', ['myApp']);

/**
 * Module for paymentMode
 */
paymentModeModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/paymentMode',    {templateUrl: 'partials/paymentmode/paymentmode_list.html', controller: 'PaymentModeCtrl'});
    $routeProvider.when('/paymentMode/new', {templateUrl: 'partials/paymentmode/paymentmode_form.html', controller: 'PaymentModeCtrl'});
    $routeProvider.when('/paymentMode/:id', {templateUrl: 'partials/paymentmode/paymentmode_form.html', controller: 'PaymentModeCtrl'});
}]);
