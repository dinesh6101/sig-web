'use strict';

/**
 * Controller for List
 **/
listModule.controller('ListCtrl', ['List',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(List, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of lists
    $scope.lists = [];
	// list to edit
    $scope.list = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh lists list
     */
    $scope.refreshListList = function() {
    	try {
			$scope.lists = [];
        	List.getAll().then(
				function(success) {
        	        $scope.lists = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh list
     */
    $scope.refreshList = function(id) {
    	try {
        	$scope.list = null;
	        List.get(id).then(
				function(success) {
        	        $scope.list = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the lists list page
     */
    $scope.goToListList = function() {
        $scope.refreshListList();
        $location.path('/list');
    }
    /**
     * Go to the list edit page
     */
    $scope.goToList = function(id) {
        $scope.refreshList(id);
        $location.path('/list/'+id);
    }

    // Actions

    /**
     * Save list
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = List.create;
			} else {
				save = List.update;
			}
			save($scope.list).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.list = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete list
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    List.delete(id).then(
				function(success) {
                	$scope.goToListList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.list = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshList($routeParams.id);
    } else {
        // List page
        $scope.refreshListList();
    }
    
    
}]);
