'use strict';

/**
 * Controller for OrderPayment
 **/
orderPaymentModule.controller('OrderPaymentCtrl', ['OrderPayment',  'PaymentMode', 'PaymentStatus', '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(OrderPayment, PaymentMode, PaymentStatus, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	 'PaymentMode',  'PaymentStatus',     // edition mode
    $scope.mode = null;
    
	// list of orderPayments
    $scope.orderPayments = [];
	// orderPayment to edit
    $scope.orderPayment = null;

	// referencies entities
	$scope.items = {};
    // paymentModes
	$scope.items.paymentModes = [];
    // paymentStatuss
	$scope.items.paymentStatuss = [];

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
		PaymentMode.getAllAsListItems().then(
				function(success) {
        	        $scope.items.paymentModes = success.data;
            	}, 
	            MessageHandler.manageError);
		PaymentStatus.getAllAsListItems().then(
				function(success) {
        	        $scope.items.paymentStatuss = success.data;
            	}, 
	            MessageHandler.manageError);
    };
    
    /**
     * Refresh orderPayments list
     */
    $scope.refreshOrderPaymentList = function() {
    	try {
			$scope.orderPayments = [];
        	OrderPayment.getAll().then(
				function(success) {
        	        $scope.orderPayments = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh orderPayment
     */
    $scope.refreshOrderPayment = function(id) {
    	try {
        	$scope.orderPayment = null;
	        OrderPayment.get(id).then(
				function(success) {
        	        $scope.orderPayment = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the orderPayments list page
     */
    $scope.goToOrderPaymentList = function() {
        $scope.refreshOrderPaymentList();
        $location.path('/orderPayment');
    }
    /**
     * Go to the orderPayment edit page
     */
    $scope.goToOrderPayment = function(id) {
        $scope.refreshOrderPayment(id);
        $location.path('/orderPayment/'+id);
    }

    // Actions

    /**
     * Save orderPayment
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = OrderPayment.create;
			} else {
				save = OrderPayment.update;
			}
			save($scope.orderPayment).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.orderPayment = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete orderPayment
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    OrderPayment.delete(id).then(
				function(success) {
                	$scope.goToOrderPaymentList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.orderPayment = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshOrderPayment($routeParams.id);
    } else {
        // List page
        $scope.refreshOrderPaymentList();
    }
    
    
}]);
