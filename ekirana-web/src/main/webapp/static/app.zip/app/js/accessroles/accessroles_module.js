'use strict';

/* Module for AccessRoles */

var accessRolesModule = angular.module('accessRoles.module', ['myApp']);

/**
 * Module for accessRoles
 */
accessRolesModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/accessRoles',    {templateUrl: 'partials/accessroles/accessroles_list.html', controller: 'AccessRolesCtrl'});
    $routeProvider.when('/accessRoles/new', {templateUrl: 'partials/accessroles/accessroles_form.html', controller: 'AccessRolesCtrl'});
    $routeProvider.when('/accessRoles/:roleid', {templateUrl: 'partials/accessroles/accessroles_form.html', controller: 'AccessRolesCtrl'});
}]);
