'use strict';

/**
 * Controller for PaymentStatus
 **/
paymentStatusModule.controller('PaymentStatusCtrl', ['PaymentStatus',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(PaymentStatus, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of paymentStatuss
    $scope.paymentStatuss = [];
	// paymentStatus to edit
    $scope.paymentStatus = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh paymentStatuss list
     */
    $scope.refreshPaymentStatusList = function() {
    	try {
			$scope.paymentStatuss = [];
        	PaymentStatus.getAll().then(
				function(success) {
        	        $scope.paymentStatuss = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh paymentStatus
     */
    $scope.refreshPaymentStatus = function(id) {
    	try {
        	$scope.paymentStatus = null;
	        PaymentStatus.get(id).then(
				function(success) {
        	        $scope.paymentStatus = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the paymentStatuss list page
     */
    $scope.goToPaymentStatusList = function() {
        $scope.refreshPaymentStatusList();
        $location.path('/paymentStatus');
    }
    /**
     * Go to the paymentStatus edit page
     */
    $scope.goToPaymentStatus = function(id) {
        $scope.refreshPaymentStatus(id);
        $location.path('/paymentStatus/'+id);
    }

    // Actions

    /**
     * Save paymentStatus
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = PaymentStatus.create;
			} else {
				save = PaymentStatus.update;
			}
			save($scope.paymentStatus).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.paymentStatus = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete paymentStatus
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    PaymentStatus.delete(id).then(
				function(success) {
                	$scope.goToPaymentStatusList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.paymentStatus = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshPaymentStatus($routeParams.id);
    } else {
        // List page
        $scope.refreshPaymentStatusList();
    }
    
    
}]);
