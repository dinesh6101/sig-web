'use strict';

/**
 * Factory for OrderTrack
 */
orderTrackModule.factory('OrderTrack', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage orderTrack
    var entityURL = restURL + '/orderTrack';
	
	/**
     * Validate orderTrack
     * @param orderTrack orderTrack
     * @throws validation exception
     */
	var validate = function (orderTrack) {
		var errors = [];
        if( orderTrack.id == null || orderTrack.id == '' ) {
			errors.push('orderTrack.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all orderTracks as list items
         * @return all orderTracks as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/orderTrack');
    	},

        /**
         * Get all orderTracks
         * @return all orderTracks
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get orderTrack
         * @param id id
         * @return orderTrack
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new orderTrack
         * @param orderTrack orderTrack
         * @return orderTrack saved
         */
		create: function(orderTrack) {
			validate(orderTrack)
			var url = entityURL;
			return $http.post(url, orderTrack);
    	},

        /**
         * Update orderTrack
         * @param orderTrack orderTrack
         * @return orderTrack saved
         */
    	update: function(orderTrack) {
			validate(orderTrack)
			var url = entityURL + '/' + orderTrack.id;
			return $http.put(url, orderTrack);
    	},

		/**
         * Delete orderTrack
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

