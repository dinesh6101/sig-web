'use strict';

/**
 * Controller for ItemCategory
 **/
itemCategoryModule.controller('ItemCategoryCtrl', ['ItemCategory',  'GroceryCategory', '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(ItemCategory, GroceryCategory, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	 'GroceryCategory',     // edition mode
    $scope.mode = null;
    
	// list of itemCategorys
    $scope.itemCategorys = [];
	// itemCategory to edit
    $scope.itemCategory = null;

	// referencies entities
	$scope.items = {};
    // groceryCategorys
	$scope.items.groceryCategorys = [];

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
		GroceryCategory.getAllAsListItems().then(
				function(success) {
        	        $scope.items.groceryCategorys = success.data;
            	}, 
	            MessageHandler.manageError);
    };
    
    /**
     * Refresh itemCategorys list
     */
    $scope.refreshItemCategoryList = function() {
    	try {
			$scope.itemCategorys = [];
        	ItemCategory.getAll().then(
				function(success) {
        	        $scope.itemCategorys = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh itemCategory
     */
    $scope.refreshItemCategory = function(itemcategoryid) {
    	try {
        	$scope.itemCategory = null;
	        ItemCategory.get(itemcategoryid).then(
				function(success) {
        	        $scope.itemCategory = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the itemCategorys list page
     */
    $scope.goToItemCategoryList = function() {
        $scope.refreshItemCategoryList();
        $location.path('/itemCategory');
    }
    /**
     * Go to the itemCategory edit page
     */
    $scope.goToItemCategory = function(itemcategoryid) {
        $scope.refreshItemCategory(itemcategoryid);
        $location.path('/itemCategory/'+itemcategoryid);
    }

    // Actions

    /**
     * Save itemCategory
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = ItemCategory.create;
			} else {
				save = ItemCategory.update;
			}
			save($scope.itemCategory).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.itemCategory = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete itemCategory
     */
    $scope.delete = function(itemcategoryid) {
	    try {
			MessageHandler.cleanMessage();
    	    ItemCategory.delete(itemcategoryid).then(
				function(success) {
                	$scope.goToItemCategoryList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.itemCategory = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.itemcategoryid != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshItemCategory($routeParams.itemcategoryid);
    } else {
        // List page
        $scope.refreshItemCategoryList();
    }
    
    
}]);
