'use strict';

/**
 * Controller for OrderTrack
 **/
orderTrackModule.controller('OrderTrackCtrl', ['OrderTrack',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(OrderTrack, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of orderTracks
    $scope.orderTracks = [];
	// orderTrack to edit
    $scope.orderTrack = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh orderTracks list
     */
    $scope.refreshOrderTrackList = function() {
    	try {
			$scope.orderTracks = [];
        	OrderTrack.getAll().then(
				function(success) {
        	        $scope.orderTracks = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh orderTrack
     */
    $scope.refreshOrderTrack = function(id) {
    	try {
        	$scope.orderTrack = null;
	        OrderTrack.get(id).then(
				function(success) {
        	        $scope.orderTrack = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the orderTracks list page
     */
    $scope.goToOrderTrackList = function() {
        $scope.refreshOrderTrackList();
        $location.path('/orderTrack');
    }
    /**
     * Go to the orderTrack edit page
     */
    $scope.goToOrderTrack = function(id) {
        $scope.refreshOrderTrack(id);
        $location.path('/orderTrack/'+id);
    }

    // Actions

    /**
     * Save orderTrack
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = OrderTrack.create;
			} else {
				save = OrderTrack.update;
			}
			save($scope.orderTrack).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.orderTrack = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete orderTrack
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    OrderTrack.delete(id).then(
				function(success) {
                	$scope.goToOrderTrackList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.orderTrack = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshOrderTrack($routeParams.id);
    } else {
        // List page
        $scope.refreshOrderTrackList();
    }
    
    
}]);
