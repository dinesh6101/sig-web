'use strict';

/* Module for KartDetails */

var kartDetailsModule = angular.module('kartDetails.module', ['myApp']);

/**
 * Module for kartDetails
 */
kartDetailsModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/kartDetails',    {templateUrl: 'partials/kartdetails/kartdetails_list.html', controller: 'KartDetailsCtrl'});
    $routeProvider.when('/kartDetails/new', {templateUrl: 'partials/kartdetails/kartdetails_form.html', controller: 'KartDetailsCtrl'});
    $routeProvider.when('/kartDetails/:id', {templateUrl: 'partials/kartdetails/kartdetails_form.html', controller: 'KartDetailsCtrl'});
}]);
