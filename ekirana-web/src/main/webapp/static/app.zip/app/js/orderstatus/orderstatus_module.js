'use strict';

/* Module for OrderStatus */

var orderStatusModule = angular.module('orderStatus.module', ['myApp']);

/**
 * Module for orderStatus
 */
orderStatusModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/orderStatus',    {templateUrl: 'partials/orderstatus/orderstatus_list.html', controller: 'OrderStatusCtrl'});
    $routeProvider.when('/orderStatus/new', {templateUrl: 'partials/orderstatus/orderstatus_form.html', controller: 'OrderStatusCtrl'});
    $routeProvider.when('/orderStatus/:id', {templateUrl: 'partials/orderstatus/orderstatus_form.html', controller: 'OrderStatusCtrl'});
}]);
