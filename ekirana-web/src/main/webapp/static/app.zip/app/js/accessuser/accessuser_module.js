'use strict';

/* Module for AccessUser */

var accessUserModule = angular.module('accessUser.module', ['myApp']);

/**
 * Module for accessUser
 */
accessUserModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/accessUser',    {templateUrl: 'partials/accessuser/accessuser_list.html', controller: 'AccessUserCtrl'});
    $routeProvider.when('/accessUser/new', {templateUrl: 'partials/accessuser/accessuser_form.html', controller: 'AccessUserCtrl'});
    $routeProvider.when('/accessUser/:userid', {templateUrl: 'partials/accessuser/accessuser_form.html', controller: 'AccessUserCtrl'});
}]);
