'use strict';

/**
 * Controller for Brand
 **/
brandModule.controller('BrandCtrl', ['Brand',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(Brand, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of brands
    $scope.brands = [];
	// brand to edit
    $scope.brand = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh brands list
     */
    $scope.refreshBrandList = function() {
    	try {
			$scope.brands = [];
        	Brand.getAll().then(
				function(success) {
        	        $scope.brands = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh brand
     */
    $scope.refreshBrand = function(brandid) {
    	try {
        	$scope.brand = null;
	        Brand.get(brandid).then(
				function(success) {
        	        $scope.brand = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the brands list page
     */
    $scope.goToBrandList = function() {
        $scope.refreshBrandList();
        $location.path('/brand');
    }
    /**
     * Go to the brand edit page
     */
    $scope.goToBrand = function(brandid) {
        $scope.refreshBrand(brandid);
        $location.path('/brand/'+brandid);
    }

    // Actions

    /**
     * Save brand
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = Brand.create;
			} else {
				save = Brand.update;
			}
			save($scope.brand).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.brand = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete brand
     */
    $scope.delete = function(brandid) {
	    try {
			MessageHandler.cleanMessage();
    	    Brand.delete(brandid).then(
				function(success) {
                	$scope.goToBrandList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.brand = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.brandid != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshBrand($routeParams.brandid);
    } else {
        // List page
        $scope.refreshBrandList();
    }
    
    
}]);
