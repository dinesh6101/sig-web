'use strict';

/**
 * Controller for CustomerOrder
 **/
customerOrderModule.controller('CustomerOrderCtrl', ['CustomerOrder',  'Customer', '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(CustomerOrder, Customer, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	 'Customer',     // edition mode
    $scope.mode = null;
    
	// list of customerOrders
    $scope.customerOrders = [];
	// customerOrder to edit
    $scope.customerOrder = null;

	// referencies entities
	$scope.items = {};
    // customers
	$scope.items.customers = [];

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
		Customer.getAllAsListItems().then(
				function(success) {
        	        $scope.items.customers = success.data;
            	}, 
	            MessageHandler.manageError);
    };
    
    /**
     * Refresh customerOrders list
     */
    $scope.refreshCustomerOrderList = function() {
    	try {
			$scope.customerOrders = [];
        	CustomerOrder.getAll().then(
				function(success) {
        	        $scope.customerOrders = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh customerOrder
     */
    $scope.refreshCustomerOrder = function(id) {
    	try {
        	$scope.customerOrder = null;
	        CustomerOrder.get(id).then(
				function(success) {
        	        $scope.customerOrder = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the customerOrders list page
     */
    $scope.goToCustomerOrderList = function() {
        $scope.refreshCustomerOrderList();
        $location.path('/customerOrder');
    }
    /**
     * Go to the customerOrder edit page
     */
    $scope.goToCustomerOrder = function(id) {
        $scope.refreshCustomerOrder(id);
        $location.path('/customerOrder/'+id);
    }

    // Actions

    /**
     * Save customerOrder
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = CustomerOrder.create;
			} else {
				save = CustomerOrder.update;
			}
			save($scope.customerOrder).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.customerOrder = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete customerOrder
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    CustomerOrder.delete(id).then(
				function(success) {
                	$scope.goToCustomerOrderList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.customerOrder = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshCustomerOrder($routeParams.id);
    } else {
        // List page
        $scope.refreshCustomerOrderList();
    }
    
    
}]);
