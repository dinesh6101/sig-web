'use strict';

/* Module for AccessRoleTokens */

var accessRoleTokensModule = angular.module('accessRoleTokens.module', ['myApp']);

/**
 * Module for accessRoleTokens
 */
accessRoleTokensModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/accessRoleTokens',    {templateUrl: 'partials/accessroletokens/accessroletokens_list.html', controller: 'AccessRoleTokensCtrl'});
    $routeProvider.when('/accessRoleTokens/new', {templateUrl: 'partials/accessroletokens/accessroletokens_form.html', controller: 'AccessRoleTokensCtrl'});
    $routeProvider.when('/accessRoleTokens/:roleTokenId', {templateUrl: 'partials/accessroletokens/accessroletokens_form.html', controller: 'AccessRoleTokensCtrl'});
}]);
