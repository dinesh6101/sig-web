'use strict';

/* Module for ItemCategory */

var itemCategoryModule = angular.module('itemCategory.module', ['myApp']);

/**
 * Module for itemCategory
 */
itemCategoryModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/itemCategory',    {templateUrl: 'partials/itemcategory/itemcategory_list.html', controller: 'ItemCategoryCtrl'});
    $routeProvider.when('/itemCategory/new', {templateUrl: 'partials/itemcategory/itemcategory_form.html', controller: 'ItemCategoryCtrl'});
    $routeProvider.when('/itemCategory/:itemcategoryid', {templateUrl: 'partials/itemcategory/itemcategory_form.html', controller: 'ItemCategoryCtrl'});
}]);
