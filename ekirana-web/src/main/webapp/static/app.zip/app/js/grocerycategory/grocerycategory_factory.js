'use strict';

/**
 * Factory for GroceryCategory
 */
groceryCategoryModule.factory('GroceryCategory', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage groceryCategory
    var entityURL = restURL + '/groceryCategory';
	
	/**
     * Validate groceryCategory
     * @param groceryCategory groceryCategory
     * @throws validation exception
     */
	var validate = function (groceryCategory) {
		var errors = [];
        if( groceryCategory.grocerycategoryid == null || groceryCategory.grocerycategoryid == '' ) {
			errors.push('groceryCategory.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all groceryCategorys as list items
         * @return all groceryCategorys as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/groceryCategory');
    	},

        /**
         * Get all groceryCategorys
         * @return all groceryCategorys
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get groceryCategory
         * @param grocerycategoryid grocerycategoryid
         * @return groceryCategory
         */
    	get: function(grocerycategoryid) {
    	    var url = entityURL + '/' + grocerycategoryid;
        	return $http.get(url);
    	},

        /**
         * Create a new groceryCategory
         * @param groceryCategory groceryCategory
         * @return groceryCategory saved
         */
		create: function(groceryCategory) {
			validate(groceryCategory)
			var url = entityURL;
			return $http.post(url, groceryCategory);
    	},

        /**
         * Update groceryCategory
         * @param groceryCategory groceryCategory
         * @return groceryCategory saved
         */
    	update: function(groceryCategory) {
			validate(groceryCategory)
			var url = entityURL + '/' + groceryCategory.grocerycategoryid;
			return $http.put(url, groceryCategory);
    	},

		/**
         * Delete groceryCategory
         * @param grocerycategoryid grocerycategoryid
         */
    	delete: function(grocerycategoryid) {
        	var url = entityURL + '/' + grocerycategoryid;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

