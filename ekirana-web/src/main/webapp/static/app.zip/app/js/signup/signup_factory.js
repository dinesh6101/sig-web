'use strict';

/**
 * Factory for SignUp
 */
signUpModule.factory('SignUp', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage accessRoleTokens
    var entityURL = restURL + '/signUp';

  //  alert('inside signup_factory.js');
	/**
     * Validate signUp
     * @param signUp signUp
     * @throws validation exception
     */
	var validate = function (signUp) {
		var errors = [];
        if( signUp.firstName == null || signUp.firstName == '' ) {
			errors.push('signUp.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all signUp as list items
         * @return all signUp as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/signUp');
    	},

        /**
         * Get all signUp
         * @return all signUp
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get signUp
         * @param firstName firstName
         * @return signUp
         */
    	get: function(firstName) {
    	    var url = entityURL + '/' + firstName;
        	return $http.get(url);
    	},

        /**
         * Create a new signUp
         * @param signUp signUp
         * @return signUp saved
         */
		create: function(signUp) {
			//validate(signUp)
			var url = entityURL;
			return $http.post(url, signUp);
    	},

        /**
         * Update signUp
         * @param signUp signUp
         * @return signUp saved
         */
    	update: function(signUp) {
			//validate(signUp);
			var url = entityURL + '/' + signUp.firstName;
			return $http.put(url, signUp);
    	},

		/**
         * Delete signUp
         * @param firstName firstName
         */
    	delete: function(firstName) {
        	var url = entityURL + '/' + firstName;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

