'use strict';

/**
 * Controller for PaymentMode
 **/
paymentModeModule.controller('PaymentModeCtrl', ['PaymentMode',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(PaymentMode, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of paymentModes
    $scope.paymentModes = [];
	// paymentMode to edit
    $scope.paymentMode = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh paymentModes list
     */
    $scope.refreshPaymentModeList = function() {
    	try {
			$scope.paymentModes = [];
        	PaymentMode.getAll().then(
				function(success) {
        	        $scope.paymentModes = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh paymentMode
     */
    $scope.refreshPaymentMode = function(id) {
    	try {
        	$scope.paymentMode = null;
	        PaymentMode.get(id).then(
				function(success) {
        	        $scope.paymentMode = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the paymentModes list page
     */
    $scope.goToPaymentModeList = function() {
        $scope.refreshPaymentModeList();
        $location.path('/paymentMode');
    }
    /**
     * Go to the paymentMode edit page
     */
    $scope.goToPaymentMode = function(id) {
        $scope.refreshPaymentMode(id);
        $location.path('/paymentMode/'+id);
    }

    // Actions

    /**
     * Save paymentMode
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = PaymentMode.create;
			} else {
				save = PaymentMode.update;
			}
			save($scope.paymentMode).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.paymentMode = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete paymentMode
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    PaymentMode.delete(id).then(
				function(success) {
                	$scope.goToPaymentModeList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.paymentMode = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshPaymentMode($routeParams.id);
    } else {
        // List page
        $scope.refreshPaymentModeList();
    }
    
    
}]);
