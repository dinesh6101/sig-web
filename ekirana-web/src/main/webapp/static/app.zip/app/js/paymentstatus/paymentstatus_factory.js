'use strict';

/**
 * Factory for PaymentStatus
 */
paymentStatusModule.factory('PaymentStatus', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage paymentStatus
    var entityURL = restURL + '/paymentStatus';
	
	/**
     * Validate paymentStatus
     * @param paymentStatus paymentStatus
     * @throws validation exception
     */
	var validate = function (paymentStatus) {
		var errors = [];
        if( paymentStatus.id == null || paymentStatus.id == '' ) {
			errors.push('paymentStatus.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all paymentStatuss as list items
         * @return all paymentStatuss as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/paymentStatus');
    	},

        /**
         * Get all paymentStatuss
         * @return all paymentStatuss
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get paymentStatus
         * @param id id
         * @return paymentStatus
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new paymentStatus
         * @param paymentStatus paymentStatus
         * @return paymentStatus saved
         */
		create: function(paymentStatus) {
			validate(paymentStatus)
			var url = entityURL;
			return $http.post(url, paymentStatus);
    	},

        /**
         * Update paymentStatus
         * @param paymentStatus paymentStatus
         * @return paymentStatus saved
         */
    	update: function(paymentStatus) {
			validate(paymentStatus)
			var url = entityURL + '/' + paymentStatus.id;
			return $http.put(url, paymentStatus);
    	},

		/**
         * Delete paymentStatus
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

