'use strict';

/**
 * Controller for AccessRoles
 **/
accessRolesModule.controller('AccessRolesCtrl', ['AccessRoles',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(AccessRoles, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of accessRoless
    $scope.accessRoless = [];
	// accessRoles to edit
    $scope.accessRoles = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh accessRoless list
     */
    $scope.refreshAccessRolesList = function() {
    	try {
			$scope.accessRoless = [];
        	AccessRoles.getAll().then(
				function(success) {
        	        $scope.accessRoless = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh accessRoles
     */
    $scope.refreshAccessRoles = function(roleid) {
    	try {
        	$scope.accessRoles = null;
	        AccessRoles.get(roleid).then(
				function(success) {
        	        $scope.accessRoles = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the accessRoless list page
     */
    $scope.goToAccessRolesList = function() {
        $scope.refreshAccessRolesList();
        $location.path('/accessRoles');
    }
    /**
     * Go to the accessRoles edit page
     */
    $scope.goToAccessRoles = function(roleid) {
        $scope.refreshAccessRoles(roleid);
        $location.path('/accessRoles/'+roleid);
    }

    // Actions

    /**
     * Save accessRoles
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = AccessRoles.create;
			} else {
				save = AccessRoles.update;
			}
			save($scope.accessRoles).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.accessRoles = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete accessRoles
     */
    $scope.delete = function(roleid) {
	    try {
			MessageHandler.cleanMessage();
    	    AccessRoles.delete(roleid).then(
				function(success) {
                	$scope.goToAccessRolesList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.accessRoles = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.roleid != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshAccessRoles($routeParams.roleid);
    } else {
        // List page
        $scope.refreshAccessRolesList();
    }
    
    
}]);
