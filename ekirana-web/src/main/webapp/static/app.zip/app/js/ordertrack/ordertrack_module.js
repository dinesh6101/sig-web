'use strict';

/* Module for OrderTrack */

var orderTrackModule = angular.module('orderTrack.module', ['myApp']);

/**
 * Module for orderTrack
 */
orderTrackModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/orderTrack',    {templateUrl: 'partials/ordertrack/ordertrack_list.html', controller: 'OrderTrackCtrl'});
    $routeProvider.when('/orderTrack/new', {templateUrl: 'partials/ordertrack/ordertrack_form.html', controller: 'OrderTrackCtrl'});
    $routeProvider.when('/orderTrack/:id', {templateUrl: 'partials/ordertrack/ordertrack_form.html', controller: 'OrderTrackCtrl'});
}]);
