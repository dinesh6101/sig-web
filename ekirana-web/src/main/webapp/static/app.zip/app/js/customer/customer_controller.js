'use strict';

/**
 * Controller for Customer
 **/
customerModule.controller('CustomerCtrl', ['Customer',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(Customer, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of customers
    $scope.customers = [];
	// customer to edit
    $scope.customer = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh customers list
     */
    $scope.refreshCustomerList = function() {
    	try {
			$scope.customers = [];
        	Customer.getAll().then(
				function(success) {
        	        $scope.customers = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh customer
     */
    $scope.refreshCustomer = function(customerid) {
    	try {
        	$scope.customer = null;
	        Customer.get(customerid).then(
				function(success) {
        	        $scope.customer = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the customers list page
     */
    $scope.goToCustomerList = function() {
        $scope.refreshCustomerList();
        $location.path('/customer');
    }
    /**
     * Go to the customer edit page
     */
    $scope.goToCustomer = function(customerid) {
        $scope.refreshCustomer(customerid);
        $location.path('/customer/'+customerid);
    }

    // Actions

    /**
     * Save customer
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = Customer.create;
			} else {
				save = Customer.update;
			}
			save($scope.customer).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.customer = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete customer
     */
    $scope.delete = function(customerid) {
	    try {
			MessageHandler.cleanMessage();
    	    Customer.delete(customerid).then(
				function(success) {
                	$scope.goToCustomerList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.customer = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.customerid != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshCustomer($routeParams.customerid);
    } else {
        // List page
        $scope.refreshCustomerList();
    }
    
    
}]);
