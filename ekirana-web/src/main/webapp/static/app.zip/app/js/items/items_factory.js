'use strict';

/**
 * Factory for Items
 */
itemsModule.factory('Items', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage items
    var entityURL = restURL + '/items';
	
	/**
     * Validate items
     * @param items items
     * @throws validation exception
     */
	var validate = function (items) {
		var errors = [];
        if( items.itemid == null || items.itemid == '' ) {
			errors.push('items.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all itemss as list items
         * @return all itemss as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/items');
    	},

        /**
         * Get all itemss
         * @return all itemss
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get items
         * @param itemid itemid
         * @return items
         */
    	get: function(itemid) {
    	    var url = entityURL + '/' + itemid;
        	return $http.get(url);
    	},

        /**
         * Create a new items
         * @param items items
         * @return items saved
         */
		create: function(items) {
			validate(items)
			var url = entityURL;
			return $http.post(url, items);
    	},

        /**
         * Update items
         * @param items items
         * @return items saved
         */
    	update: function(items) {
			validate(items)
			var url = entityURL + '/' + items.itemid;
			return $http.put(url, items);
    	},

		/**
         * Delete items
         * @param itemid itemid
         */
    	delete: function(itemid) {
        	var url = entityURL + '/' + itemid;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

