'use strict';

/**
 * Factory for OrderPayment
 */
orderPaymentModule.factory('OrderPayment', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage orderPayment
    var entityURL = restURL + '/orderPayment';
	
	/**
     * Validate orderPayment
     * @param orderPayment orderPayment
     * @throws validation exception
     */
	var validate = function (orderPayment) {
		var errors = [];
        if( orderPayment.id == null || orderPayment.id == '' ) {
			errors.push('orderPayment.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all orderPayments as list items
         * @return all orderPayments as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/orderPayment');
    	},

        /**
         * Get all orderPayments
         * @return all orderPayments
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get orderPayment
         * @param id id
         * @return orderPayment
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new orderPayment
         * @param orderPayment orderPayment
         * @return orderPayment saved
         */
		create: function(orderPayment) {
			validate(orderPayment)
			var url = entityURL;
			return $http.post(url, orderPayment);
    	},

        /**
         * Update orderPayment
         * @param orderPayment orderPayment
         * @return orderPayment saved
         */
    	update: function(orderPayment) {
			validate(orderPayment)
			var url = entityURL + '/' + orderPayment.id;
			return $http.put(url, orderPayment);
    	},

		/**
         * Delete orderPayment
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

