'use strict';

/**
 * Factory for KartDetails
 */
kartDetailsModule.factory('KartDetails', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage kartDetails
    var entityURL = restURL + '/kartDetails';
	
	/**
     * Validate kartDetails
     * @param kartDetails kartDetails
     * @throws validation exception
     */
	var validate = function (kartDetails) {
		var errors = [];
        if( kartDetails.id == null || kartDetails.id == '' ) {
			errors.push('kartDetails.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all kartDetailss as list items
         * @return all kartDetailss as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/kartDetails');
    	},

        /**
         * Get all kartDetailss
         * @return all kartDetailss
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get kartDetails
         * @param id id
         * @return kartDetails
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new kartDetails
         * @param kartDetails kartDetails
         * @return kartDetails saved
         */
		create: function(kartDetails) {
			validate(kartDetails)
			var url = entityURL;
			return $http.post(url, kartDetails);
    	},

        /**
         * Update kartDetails
         * @param kartDetails kartDetails
         * @return kartDetails saved
         */
    	update: function(kartDetails) {
			validate(kartDetails)
			var url = entityURL + '/' + kartDetails.id;
			return $http.put(url, kartDetails);
    	},

		/**
         * Delete kartDetails
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

