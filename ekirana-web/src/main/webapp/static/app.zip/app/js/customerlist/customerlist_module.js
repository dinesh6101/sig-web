'use strict';

/* Module for CustomerList */

var customerListModule = angular.module('customerList.module', ['myApp']);

/**
 * Module for customerList
 */
customerListModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/customerList',    {templateUrl: 'partials/customerlist/customerlist_list.html', controller: 'CustomerListCtrl'});
    $routeProvider.when('/customerList/new', {templateUrl: 'partials/customerlist/customerlist_form.html', controller: 'CustomerListCtrl'});
    $routeProvider.when('/customerList/:id', {templateUrl: 'partials/customerlist/customerlist_form.html', controller: 'CustomerListCtrl'});
}]);
