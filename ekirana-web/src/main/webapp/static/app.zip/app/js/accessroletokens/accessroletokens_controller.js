'use strict';

/**
 * Controller for AccessRoleTokens
 **/
accessRoleTokensModule.controller('AccessRoleTokensCtrl', ['AccessRoleTokens',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(AccessRoleTokens, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of accessRoleTokenss
    $scope.accessRoleTokenss = [];
	// accessRoleTokens to edit
    $scope.accessRoleTokens = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh accessRoleTokenss list
     */
    $scope.refreshAccessRoleTokensList = function() {
    	try {
			$scope.accessRoleTokenss = [];
        	AccessRoleTokens.getAll().then(
				function(success) {
        	        $scope.accessRoleTokenss = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh accessRoleTokens
     */
    $scope.refreshAccessRoleTokens = function(roleTokenId) {
    	try {
        	$scope.accessRoleTokens = null;
	        AccessRoleTokens.get(roleTokenId).then(
				function(success) {
        	        $scope.accessRoleTokens = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the accessRoleTokenss list page
     */
    $scope.goToAccessRoleTokensList = function() {
        $scope.refreshAccessRoleTokensList();
        $location.path('/accessRoleTokens');
    }
    /**
     * Go to the accessRoleTokens edit page
     */
    $scope.goToAccessRoleTokens = function(roleTokenId) {
        $scope.refreshAccessRoleTokens(roleTokenId);
        $location.path('/accessRoleTokens/'+roleTokenId);
    }

    // Actions

    /**
     * Save accessRoleTokens
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = AccessRoleTokens.create;
			} else {
				save = AccessRoleTokens.update;
			}
			save($scope.accessRoleTokens).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.accessRoleTokens = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete accessRoleTokens
     */
    $scope.delete = function(roleTokenId) {
	    try {
			MessageHandler.cleanMessage();
    	    AccessRoleTokens.delete(roleTokenId).then(
				function(success) {
                	$scope.goToAccessRoleTokensList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.accessRoleTokens = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.roleTokenId != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshAccessRoleTokens($routeParams.roleTokenId);
    } else {
        // List page
        $scope.refreshAccessRoleTokensList();
    }
    
    
}]);
