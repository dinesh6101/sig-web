'use strict';

/* Module for CustomerOrder */

var customerOrderModule = angular.module('customerOrder.module', ['myApp']);

/**
 * Module for customerOrder
 */
customerOrderModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/customerOrder',    {templateUrl: 'partials/customerorder/customerorder_list.html', controller: 'CustomerOrderCtrl'});
    $routeProvider.when('/customerOrder/new', {templateUrl: 'partials/customerorder/customerorder_form.html', controller: 'CustomerOrderCtrl'});
    $routeProvider.when('/customerOrder/:id', {templateUrl: 'partials/customerorder/customerorder_form.html', controller: 'CustomerOrderCtrl'});
}]);
