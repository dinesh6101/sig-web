'use strict';

/**
 * Controller for OrderStatus
 **/
orderStatusModule.controller('OrderStatusCtrl', ['OrderStatus',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(OrderStatus, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of orderStatuss
    $scope.orderStatuss = [];
	// orderStatus to edit
    $scope.orderStatus = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh orderStatuss list
     */
    $scope.refreshOrderStatusList = function() {
    	try {
			$scope.orderStatuss = [];
        	OrderStatus.getAll().then(
				function(success) {
        	        $scope.orderStatuss = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh orderStatus
     */
    $scope.refreshOrderStatus = function(id) {
    	try {
        	$scope.orderStatus = null;
	        OrderStatus.get(id).then(
				function(success) {
        	        $scope.orderStatus = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the orderStatuss list page
     */
    $scope.goToOrderStatusList = function() {
        $scope.refreshOrderStatusList();
        $location.path('/orderStatus');
    }
    /**
     * Go to the orderStatus edit page
     */
    $scope.goToOrderStatus = function(id) {
        $scope.refreshOrderStatus(id);
        $location.path('/orderStatus/'+id);
    }

    // Actions

    /**
     * Save orderStatus
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = OrderStatus.create;
			} else {
				save = OrderStatus.update;
			}
			save($scope.orderStatus).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.orderStatus = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete orderStatus
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    OrderStatus.delete(id).then(
				function(success) {
                	$scope.goToOrderStatusList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.orderStatus = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshOrderStatus($routeParams.id);
    } else {
        // List page
        $scope.refreshOrderStatusList();
    }
    
    
}]);
