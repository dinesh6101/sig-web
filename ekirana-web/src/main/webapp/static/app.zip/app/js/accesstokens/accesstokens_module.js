'use strict';

/* Module for AccessTokens */

var accessTokensModule = angular.module('accessTokens.module', ['myApp']);

/**
 * Module for accessTokens
 */
accessTokensModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/accessTokens',    {templateUrl: 'partials/accesstokens/accesstokens_list.html', controller: 'AccessTokensCtrl'});
    $routeProvider.when('/accessTokens/new', {templateUrl: 'partials/accesstokens/accesstokens_form.html', controller: 'AccessTokensCtrl'});
    $routeProvider.when('/accessTokens/:tokenid', {templateUrl: 'partials/accesstokens/accesstokens_form.html', controller: 'AccessTokensCtrl'});
}]);
