'use strict';

/**
 * Factory for CustomerOrder
 */
customerOrderModule.factory('CustomerOrder', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage customerOrder
    var entityURL = restURL + '/customerOrder';
	
	/**
     * Validate customerOrder
     * @param customerOrder customerOrder
     * @throws validation exception
     */
	var validate = function (customerOrder) {
		var errors = [];
        if( customerOrder.id == null || customerOrder.id == '' ) {
			errors.push('customerOrder.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all customerOrders as list items
         * @return all customerOrders as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/customerOrder');
    	},

        /**
         * Get all customerOrders
         * @return all customerOrders
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get customerOrder
         * @param id id
         * @return customerOrder
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new customerOrder
         * @param customerOrder customerOrder
         * @return customerOrder saved
         */
		create: function(customerOrder) {
			validate(customerOrder)
			var url = entityURL;
			return $http.post(url, customerOrder);
    	},

        /**
         * Update customerOrder
         * @param customerOrder customerOrder
         * @return customerOrder saved
         */
    	update: function(customerOrder) {
			validate(customerOrder)
			var url = entityURL + '/' + customerOrder.id;
			return $http.put(url, customerOrder);
    	},

		/**
         * Delete customerOrder
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

