'use strict';

/**
 * Factory for AccessRoles
 */
accessRolesModule.factory('AccessRoles', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage accessRoles
    var entityURL = restURL + '/accessRoles';
	
	/**
     * Validate accessRoles
     * @param accessRoles accessRoles
     * @throws validation exception
     */
	var validate = function (accessRoles) {
		var errors = [];
        if( accessRoles.roleid == null || accessRoles.roleid == '' ) {
			errors.push('accessRoles.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all accessRoless as list items
         * @return all accessRoless as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/accessRoles');
    	},

        /**
         * Get all accessRoless
         * @return all accessRoless
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get accessRoles
         * @param roleid roleid
         * @return accessRoles
         */
    	get: function(roleid) {
    	    var url = entityURL + '/' + roleid;
        	return $http.get(url);
    	},

        /**
         * Create a new accessRoles
         * @param accessRoles accessRoles
         * @return accessRoles saved
         */
		create: function(accessRoles) {
			validate(accessRoles)
			var url = entityURL;
			return $http.post(url, accessRoles);
    	},

        /**
         * Update accessRoles
         * @param accessRoles accessRoles
         * @return accessRoles saved
         */
    	update: function(accessRoles) {
			validate(accessRoles)
			var url = entityURL + '/' + accessRoles.roleid;
			return $http.put(url, accessRoles);
    	},

		/**
         * Delete accessRoles
         * @param roleid roleid
         */
    	delete: function(roleid) {
        	var url = entityURL + '/' + roleid;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

