'use strict';

/**
 * Factory for ItemCategory
 */
itemCategoryModule.factory('ItemCategory', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage itemCategory
    var entityURL = restURL + '/itemCategory';
	
	/**
     * Validate itemCategory
     * @param itemCategory itemCategory
     * @throws validation exception
     */
	var validate = function (itemCategory) {
		var errors = [];
        if( itemCategory.itemcategoryid == null || itemCategory.itemcategoryid == '' ) {
			errors.push('itemCategory.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all itemCategorys as list items
         * @return all itemCategorys as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/itemCategory');
    	},

        /**
         * Get all itemCategorys
         * @return all itemCategorys
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get itemCategory
         * @param itemcategoryid itemcategoryid
         * @return itemCategory
         */
    	get: function(itemcategoryid) {
    	    var url = entityURL + '/' + itemcategoryid;
        	return $http.get(url);
    	},

        /**
         * Create a new itemCategory
         * @param itemCategory itemCategory
         * @return itemCategory saved
         */
		create: function(itemCategory) {
			validate(itemCategory)
			var url = entityURL;
			return $http.post(url, itemCategory);
    	},

        /**
         * Update itemCategory
         * @param itemCategory itemCategory
         * @return itemCategory saved
         */
    	update: function(itemCategory) {
			validate(itemCategory)
			var url = entityURL + '/' + itemCategory.itemcategoryid;
			return $http.put(url, itemCategory);
    	},

		/**
         * Delete itemCategory
         * @param itemcategoryid itemcategoryid
         */
    	delete: function(itemcategoryid) {
        	var url = entityURL + '/' + itemcategoryid;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

