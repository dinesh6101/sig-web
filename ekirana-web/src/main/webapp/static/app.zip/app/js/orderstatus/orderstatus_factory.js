'use strict';

/**
 * Factory for OrderStatus
 */
orderStatusModule.factory('OrderStatus', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage orderStatus
    var entityURL = restURL + '/orderStatus';
	
	/**
     * Validate orderStatus
     * @param orderStatus orderStatus
     * @throws validation exception
     */
	var validate = function (orderStatus) {
		var errors = [];
        if( orderStatus.id == null || orderStatus.id == '' ) {
			errors.push('orderStatus.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all orderStatuss as list items
         * @return all orderStatuss as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/orderStatus');
    	},

        /**
         * Get all orderStatuss
         * @return all orderStatuss
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get orderStatus
         * @param id id
         * @return orderStatus
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new orderStatus
         * @param orderStatus orderStatus
         * @return orderStatus saved
         */
		create: function(orderStatus) {
			validate(orderStatus)
			var url = entityURL;
			return $http.post(url, orderStatus);
    	},

        /**
         * Update orderStatus
         * @param orderStatus orderStatus
         * @return orderStatus saved
         */
    	update: function(orderStatus) {
			validate(orderStatus)
			var url = entityURL + '/' + orderStatus.id;
			return $http.put(url, orderStatus);
    	},

		/**
         * Delete orderStatus
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

