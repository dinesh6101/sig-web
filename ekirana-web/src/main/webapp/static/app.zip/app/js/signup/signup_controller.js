'use strict';

/**
 * Controller for SignUp
 */
signUpModule.controller('SignUpCtrl', ['SignUp',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(SignUp, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of signUp
    $scope.signUp = [];
	// signUp to edit
    $scope.signUp = null;

	// referencies entities
	$scope.items = {};
//	alert('inside signup_controller.js');
    /**
	 * Load all referencies entities
	 */
	$scope.loadAllReferencies = function() {
    };
    
    /**
	 * Refresh signUp list
	 */
    $scope.refreshSignUpList = function() {
    	try {
			$scope.signUp = [];
        	signUp.getAll().then(
				function(success) {
        	        $scope.signUp = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
	 * Refresh signUp
	 */
    $scope.refreshSignUp = function(signUp) {
    	try {
        	$scope.signUp = null;
	        signUp.get(firstName).then(
				function(success) {
        	        $scope.signUp = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
	 * Go to the accessRoleTokenss list page
	 */
    $scope.goToSignUpList = function() {
        $scope.refreshSignUpList();
        $location.path('/signUp');
    }
    /**
	 * Go to the accessRoleTokens edit page
	 */
    $scope.goToSignUp = function(firstName) {
        $scope.refreshSignUp(firstName);
        $location.path('/signUp/'+firstName);
    }

    // Actions

    /**
	 * Save accessRoleTokens
	 */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			alert('Inside save');
			var save;
			if( $scope.mode === 'create' ) {
        		save = SignUp.create;
			} else {
				save = SignUp.update;
			}
			save($scope.signUp).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.signUp = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
	 * Delete accessRoleTokens
	 */
    $scope.delete = function(roleTokenId) {
	    try {
			MessageHandler.cleanMessage();
    	    SignUp.delete(firstName).then(
				function(success) {
                	$scope.goToSignUpList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.signUp = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.firstName != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshSignUp($routeParams.roleTokenId);
    } else {
        // List page
        $scope.refreshSignUpList();
    }
    
    
}]);
