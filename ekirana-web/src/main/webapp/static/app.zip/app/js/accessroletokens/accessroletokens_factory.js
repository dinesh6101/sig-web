'use strict';

/**
 * Factory for AccessRoleTokens
 */
accessRoleTokensModule.factory('AccessRoleTokens', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage accessRoleTokens
    var entityURL = restURL + '/accessRoleTokens';
	
	/**
     * Validate accessRoleTokens
     * @param accessRoleTokens accessRoleTokens
     * @throws validation exception
     */
	var validate = function (accessRoleTokens) {
		var errors = [];
        if( accessRoleTokens.roleTokenId == null || accessRoleTokens.roleTokenId == '' ) {
			errors.push('accessRoleTokens.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all accessRoleTokenss as list items
         * @return all accessRoleTokenss as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/accessRoleTokens');
    	},

        /**
         * Get all accessRoleTokenss
         * @return all accessRoleTokenss
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get accessRoleTokens
         * @param roleTokenId roleTokenId
         * @return accessRoleTokens
         */
    	get: function(roleTokenId) {
    	    var url = entityURL + '/' + roleTokenId;
        	return $http.get(url);
    	},

        /**
         * Create a new accessRoleTokens
         * @param accessRoleTokens accessRoleTokens
         * @return accessRoleTokens saved
         */
		create: function(accessRoleTokens) {
			validate(accessRoleTokens)
			var url = entityURL;
			return $http.post(url, accessRoleTokens);
    	},

        /**
         * Update accessRoleTokens
         * @param accessRoleTokens accessRoleTokens
         * @return accessRoleTokens saved
         */
    	update: function(accessRoleTokens) {
			validate(accessRoleTokens)
			var url = entityURL + '/' + accessRoleTokens.roleTokenId;
			return $http.put(url, accessRoleTokens);
    	},

		/**
         * Delete accessRoleTokens
         * @param roleTokenId roleTokenId
         */
    	delete: function(roleTokenId) {
        	var url = entityURL + '/' + roleTokenId;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

