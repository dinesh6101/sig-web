'use strict';

/**
 * Factory for CustomerList
 */
customerListModule.factory('CustomerList', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage customerList
    var entityURL = restURL + '/customerList';
	
	/**
     * Validate customerList
     * @param customerList customerList
     * @throws validation exception
     */
	var validate = function (customerList) {
		var errors = [];
        if( customerList.id == null || customerList.id == '' ) {
			errors.push('customerList.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all customerLists as list items
         * @return all customerLists as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/customerList');
    	},

        /**
         * Get all customerLists
         * @return all customerLists
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get customerList
         * @param id id
         * @return customerList
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new customerList
         * @param customerList customerList
         * @return customerList saved
         */
		create: function(customerList) {
			validate(customerList)
			var url = entityURL;
			return $http.post(url, customerList);
    	},

        /**
         * Update customerList
         * @param customerList customerList
         * @return customerList saved
         */
    	update: function(customerList) {
			validate(customerList)
			var url = entityURL + '/' + customerList.id;
			return $http.put(url, customerList);
    	},

		/**
         * Delete customerList
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

