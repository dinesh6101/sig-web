'use strict';

/* Module for Items */

var itemsModule = angular.module('items.module', ['myApp']);

/**
 * Module for items
 */
itemsModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/items',    {templateUrl: 'partials/items/items_list.html', controller: 'ItemsCtrl'});
    $routeProvider.when('/items/new', {templateUrl: 'partials/items/items_form.html', controller: 'ItemsCtrl'});
    $routeProvider.when('/items/:itemid', {templateUrl: 'partials/items/items_form.html', controller: 'ItemsCtrl'});
}]);
