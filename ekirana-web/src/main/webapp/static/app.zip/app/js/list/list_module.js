'use strict';

/* Module for List */

var listModule = angular.module('list.module', ['myApp']);

/**
 * Module for list
 */
listModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/list',    {templateUrl: 'partials/list/list_list.html', controller: 'ListCtrl'});
    $routeProvider.when('/list/new', {templateUrl: 'partials/list/list_form.html', controller: 'ListCtrl'});
    $routeProvider.when('/list/:id', {templateUrl: 'partials/list/list_form.html', controller: 'ListCtrl'});
}]);
