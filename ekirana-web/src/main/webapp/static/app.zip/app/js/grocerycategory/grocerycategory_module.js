'use strict';

/* Module for GroceryCategory */

var groceryCategoryModule = angular.module('groceryCategory.module', ['myApp']);

/**
 * Module for groceryCategory
 */
groceryCategoryModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/groceryCategory',    {templateUrl: 'partials/grocerycategory/grocerycategory_list.html', controller: 'GroceryCategoryCtrl'});
    $routeProvider.when('/groceryCategory/new', {templateUrl: 'partials/grocerycategory/grocerycategory_form.html', controller: 'GroceryCategoryCtrl'});
    $routeProvider.when('/groceryCategory/:grocerycategoryid', {templateUrl: 'partials/grocerycategory/grocerycategory_form.html', controller: 'GroceryCategoryCtrl'});
}]);
