'use strict';

/**
 * Factory for PaymentMode
 */
paymentModeModule.factory('PaymentMode', ['$http', 'restURL', function($http, restURL) {

	// REST Service URL to manage paymentMode
    var entityURL = restURL + '/paymentMode';
	
	/**
     * Validate paymentMode
     * @param paymentMode paymentMode
     * @throws validation exception
     */
	var validate = function (paymentMode) {
		var errors = [];
        if( paymentMode.id == null || paymentMode.id == '' ) {
			errors.push('paymentMode.id.not.defined');
		}
		if(errors.length > 0) {
			throw errors;
		}
    };
	
	return {
        /**
         * Get all paymentModes as list items
         * @return all paymentModes as list items
         */
    	getAllAsListItems: function() {
        	return $http.get(restURL + '/items/paymentMode');
    	},

        /**
         * Get all paymentModes
         * @return all paymentModes
         */
    	getAll: function() {
        	return $http.get(entityURL);
    	},

        /**
         * Get paymentMode
         * @param id id
         * @return paymentMode
         */
    	get: function(id) {
    	    var url = entityURL + '/' + id;
        	return $http.get(url);
    	},

        /**
         * Create a new paymentMode
         * @param paymentMode paymentMode
         * @return paymentMode saved
         */
		create: function(paymentMode) {
			validate(paymentMode)
			var url = entityURL;
			return $http.post(url, paymentMode);
    	},

        /**
         * Update paymentMode
         * @param paymentMode paymentMode
         * @return paymentMode saved
         */
    	update: function(paymentMode) {
			validate(paymentMode)
			var url = entityURL + '/' + paymentMode.id;
			return $http.put(url, paymentMode);
    	},

		/**
         * Delete paymentMode
         * @param id id
         */
    	delete: function(id) {
        	var url = entityURL + '/' + id;
        	return $http.delete(url);
    	}
	};
	return $this;
}]);

