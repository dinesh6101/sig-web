'use strict';

/**
 * Controller for ItemOffers
 **/
itemOffersModule.controller('ItemOffersCtrl', ['ItemOffers',  'Items', '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(ItemOffers, Items, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	 'Items',     // edition mode
    $scope.mode = null;
    
	// list of itemOfferss
    $scope.itemOfferss = [];
	// itemOffers to edit
    $scope.itemOffers = null;

	// referencies entities
	$scope.items = {};
    // itemss
	$scope.items.itemss = [];

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
		Items.getAllAsListItems().then(
				function(success) {
        	        $scope.items.itemss = success.data;
            	}, 
	            MessageHandler.manageError);
    };
    
    /**
     * Refresh itemOfferss list
     */
    $scope.refreshItemOffersList = function() {
    	try {
			$scope.itemOfferss = [];
        	ItemOffers.getAll().then(
				function(success) {
        	        $scope.itemOfferss = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh itemOffers
     */
    $scope.refreshItemOffers = function(id) {
    	try {
        	$scope.itemOffers = null;
	        ItemOffers.get(id).then(
				function(success) {
        	        $scope.itemOffers = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the itemOfferss list page
     */
    $scope.goToItemOffersList = function() {
        $scope.refreshItemOffersList();
        $location.path('/itemOffers');
    }
    /**
     * Go to the itemOffers edit page
     */
    $scope.goToItemOffers = function(id) {
        $scope.refreshItemOffers(id);
        $location.path('/itemOffers/'+id);
    }

    // Actions

    /**
     * Save itemOffers
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = ItemOffers.create;
			} else {
				save = ItemOffers.update;
			}
			save($scope.itemOffers).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.itemOffers = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete itemOffers
     */
    $scope.delete = function(id) {
	    try {
			MessageHandler.cleanMessage();
    	    ItemOffers.delete(id).then(
				function(success) {
                	$scope.goToItemOffersList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.itemOffers = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.id != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshItemOffers($routeParams.id);
    } else {
        // List page
        $scope.refreshItemOffersList();
    }
    
    
}]);
