'use strict';

/**
 * Controller for AccessTokens
 **/
accessTokensModule.controller('AccessTokensCtrl', ['AccessTokens',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(AccessTokens, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of accessTokenss
    $scope.accessTokenss = [];
	// accessTokens to edit
    $scope.accessTokens = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh accessTokenss list
     */
    $scope.refreshAccessTokensList = function() {
    	try {
			$scope.accessTokenss = [];
        	AccessTokens.getAll().then(
				function(success) {
        	        $scope.accessTokenss = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh accessTokens
     */
    $scope.refreshAccessTokens = function(tokenid) {
    	try {
        	$scope.accessTokens = null;
	        AccessTokens.get(tokenid).then(
				function(success) {
        	        $scope.accessTokens = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the accessTokenss list page
     */
    $scope.goToAccessTokensList = function() {
        $scope.refreshAccessTokensList();
        $location.path('/accessTokens');
    }
    /**
     * Go to the accessTokens edit page
     */
    $scope.goToAccessTokens = function(tokenid) {
        $scope.refreshAccessTokens(tokenid);
        $location.path('/accessTokens/'+tokenid);
    }

    // Actions

    /**
     * Save accessTokens
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = AccessTokens.create;
			} else {
				save = AccessTokens.update;
			}
			save($scope.accessTokens).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.accessTokens = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete accessTokens
     */
    $scope.delete = function(tokenid) {
	    try {
			MessageHandler.cleanMessage();
    	    AccessTokens.delete(tokenid).then(
				function(success) {
                	$scope.goToAccessTokensList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.accessTokens = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.tokenid != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshAccessTokens($routeParams.tokenid);
    } else {
        // List page
        $scope.refreshAccessTokensList();
    }
    
    
}]);
