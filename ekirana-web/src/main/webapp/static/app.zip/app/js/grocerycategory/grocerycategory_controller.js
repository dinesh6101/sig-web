'use strict';

/**
 * Controller for GroceryCategory
 **/
groceryCategoryModule.controller('GroceryCategoryCtrl', ['GroceryCategory',  '$scope', '$routeParams', '$http', '$location', '$cookies', 'MessageHandler', 'restURL', function(GroceryCategory, $scope, $routeParams, $http, $location, $cookies, MessageHandler, restURL) {
	    // edition mode
    $scope.mode = null;
    
	// list of groceryCategorys
    $scope.groceryCategorys = [];
	// groceryCategory to edit
    $scope.groceryCategory = null;

	// referencies entities
	$scope.items = {};

    /**
     * Load all referencies entities
     */
	$scope.loadAllReferencies = function() {
    };
    
    /**
     * Refresh groceryCategorys list
     */
    $scope.refreshGroceryCategoryList = function() {
    	try {
			$scope.groceryCategorys = [];
        	GroceryCategory.getAll().then(
				function(success) {
        	        $scope.groceryCategorys = success.data;
            	}, 
	            MessageHandler.manageError);
    	} catch(ex) {
    		MessageHandler.manageException(ex);
    	}
    }
    /**
     * Refresh groceryCategory
     */
    $scope.refreshGroceryCategory = function(grocerycategoryid) {
    	try {
        	$scope.groceryCategory = null;
	        GroceryCategory.get(grocerycategoryid).then(
				function(success) {
        	        $scope.groceryCategory = success.data;
            	}, 
	            MessageHandler.manageError);
    	  } catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    }

    /**
     * Go to the groceryCategorys list page
     */
    $scope.goToGroceryCategoryList = function() {
        $scope.refreshGroceryCategoryList();
        $location.path('/groceryCategory');
    }
    /**
     * Go to the groceryCategory edit page
     */
    $scope.goToGroceryCategory = function(grocerycategoryid) {
        $scope.refreshGroceryCategory(grocerycategoryid);
        $location.path('/groceryCategory/'+grocerycategoryid);
    }

    // Actions

    /**
     * Save groceryCategory
     */
    $scope.save = function() {
    	try {
			MessageHandler.cleanMessage();
			var save;
			if( $scope.mode === 'create' ) {
        		save = GroceryCategory.create;
			} else {
				save = GroceryCategory.update;
			}
			save($scope.groceryCategory).then(
    	        function(success) {
	                MessageHandler.addSuccess('save ok');
                	$scope.groceryCategory = success.data;
            	},
        	    MessageHandler.manageError);
    	} catch(ex) {
        	MessageHandler.manageException(ex);
    	}
    };
    /**
     * Delete groceryCategory
     */
    $scope.delete = function(grocerycategoryid) {
	    try {
			MessageHandler.cleanMessage();
    	    GroceryCategory.delete(grocerycategoryid).then(
				function(success) {
                	$scope.goToGroceryCategoryList();
            	}, 
                MessageHandler.manageError);
        } catch(ex) {
            MessageHandler.manageException(ex);
        }
    };
    
    // Main
	MessageHandler.cleanMessage();
    if( $location.path().endsWith('/new') ) {
        // Creation page
        $scope.groceryCategory = {};
        $scope.mode = 'create';
		$scope.loadAllReferencies();
        $scope.bookorderitem = null;
    } else if( $routeParams.grocerycategoryid != null ) {
        // Edit page
		$scope.loadAllReferencies();
		$scope.refreshGroceryCategory($routeParams.grocerycategoryid);
    } else {
        // List page
        $scope.refreshGroceryCategoryList();
    }
    
    
}]);
