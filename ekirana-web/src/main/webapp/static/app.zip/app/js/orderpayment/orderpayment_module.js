'use strict';

/* Module for OrderPayment */

var orderPaymentModule = angular.module('orderPayment.module', ['myApp']);

/**
 * Module for orderPayment
 */
orderPaymentModule.config(['$routeProvider', function($routeProvider) {
    // Pages routes
    $routeProvider.when('/orderPayment',    {templateUrl: 'partials/orderpayment/orderpayment_list.html', controller: 'OrderPaymentCtrl'});
    $routeProvider.when('/orderPayment/new', {templateUrl: 'partials/orderpayment/orderpayment_form.html', controller: 'OrderPaymentCtrl'});
    $routeProvider.when('/orderPayment/:id', {templateUrl: 'partials/orderpayment/orderpayment_form.html', controller: 'OrderPaymentCtrl'});
}]);
